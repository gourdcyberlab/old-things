from scapy.all import *
import nfqueue, socket

q = nfqueue.queue()
q.open()
q.bind(socket.AF_INET)
q.set_callback(ReplyAll)
q.create_queue(0)

try:
	q.try_run()
except KeyboardInterrupt:
	print "Exiting..."
q.unbind(socket.AF_INET)
q.close()

def pingReply(pkt):
	
	print ':::PING REPLY:::'
	if pkt[2].type == 8:
		temp = pkt
		print pkt.summary()
		print pkt.src
		pinger = pkt[1]
		#pinger.src = '10.0.0.1'
		pinger.dst = '10.0.0.200'
		del pinger.chksum
		print 'PINGER:'
		print pinger.summary()
		ans, unans = sr(pinger)
		print 'REPLY:'
		print ans[0][1].summary()
		reply = ans[0][1]
		#reply.dst = pkt[1].src
		reply.src = pkt[1].dst
		del reply.chksum
		send(reply)
		print 'Reply Sent!'
		reply.summary()
		print '\n\n'
	else:
		print pkt.summary()
		print "SCRAPPED"

def ReplyAll(pkt):
	#if ICMP in pkt:
	#	pingReply(pkt)
	#print pkt.summary()	
	if IP in pkt and pkt[IP].src == '10.1.0.100':
		#print 'CAPTURED!'
		#print pkt.summary()
		msg = pkt[1]
		del msg.chksum
		msg.dst = '10.0.0.200'
		#print 'FAKE MSG::::::'
		#print msg.summary()
		ans, unans = sr(msg,timeout=0.003)
		for response in ans:
			#print 'RESPONSE:::'
			toAtk = response[1]
			#print toAtk.summary()
			toAtk.src = pkt[IP].dst
			#print 'MSG TO ATTACKER:::'
			#print toAtk.summary()
			del toAtk.chksum
			send(toAtk)
sniff(prn=ReplyAll, iface='eth1', store=0)
